import React, {useState} from "react";
import './App.css';

let list = ["test1","test2"];
let sum = [10,20,30];

var newListItem = document.getElementById("name");
var newNumber= document.getElementById("cost");

function addToArray () {
  console.log(list);
  console.log(sum);
  list.push(newListItem);
  sum.push(document.getElementById("cost"));
  console.log("i got clicked");
  console.log(list);
  console.log(sum);

}





function App() {
  
  return (

    
    <div className="App">
      <div className='input-container'>

        <h1>Add Expense</h1>
        <form>
        <div className='inputs'>

        <label for="name">Name</label>
        <input name="name" id="name"></input>

        </div>

        <div className='inputs'>

        <label for="cost">Cost</label>
        <input name="cost" id="cost"></input>

        </div>
        </form>

        <button onClick={addToArray} id="btn">Add</button>

      </div>

      <div className='lists'>
      <p>
      List: [{list.map(function (item) {
      return item + ", "
      })}
      ]</p>

      <p>
        Sum: {sum.reduce(function (a,b) {
          return a + b;
        })}
      </p>
      </div>
    </div>
  );
}

export default App;
